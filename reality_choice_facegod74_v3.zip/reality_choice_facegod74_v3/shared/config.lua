Config = {}

Config.Branding = {
    ScriptName = 'Reality Choice',
    MadeBy = 'facegod74'
}

-- Framework: 'standalone', 'qb', or 'esx'
Config.Framework = 'standalone'

-- Inventory: 'ox', 'qb', or 'none'
Config.Inventory = 'ox'

Config.Debug = false

Config.Items = {
    Blue = 'reality_bluepill',
    Red = 'reality_redpill',
    Gold = 'reality_goldpill'
}

Config.Durations = {
    Blue = 120, -- seconds
    Red = 120,
    Gold = 300,
    RealityCrash = 60
}

Config.Cooldown = 20 -- seconds between pill usage

Config.GoldCrafting = {
    Enabled = true,
    Command = 'realitycraftgold',
    BlueRequired = 1,
    RedRequired = 1,
    CashCost = 10000,
    SuccessChance = 1, -- 1% chance
    ConsumeItemsOnFail = true,
    RefundCashOnFail = false,
    AnnounceSuccess = true
}

Config.Effects = {
    Blue = {
        Timecycle = 'scanline_cam_cheap',
        MovementMultiplier = 1.0,
        StressRelief = 15,
        ArmorBonus = 0,
        EnableNightVision = false,
        EnableThermal = false,
        ScreenShake = 0.05
    },
    Red = {
        Timecycle = 'damage',
        MovementMultiplier = 1.12,
        StressRelief = 0,
        ArmorBonus = 10,
        EnableNightVision = false,
        EnableThermal = false,
        ScreenShake = 0.18
    },
    Gold = {
        Timecycle = 'MP_corona_switch',
        MovementMultiplier = 1.15,
        StressRelief = 25,
        ArmorBonus = 25,
        EnableNightVision = true,
        EnableThermal = false,
        ScreenShake = 0.10,
        RealityCrashChance = 15
    }
}

Config.Commands = {
    GiveTestPills = true,
    GiveTestCommand = 'realitytest', -- gives all pills for testing. Disable before public launch.
    ClearEffectCommand = 'realityclear'
}

Config.Notifications = {
    BlueStart = 'You chose the BLUE PILL. Reality feels cold and clear.',
    RedStart = 'You chose the RED PILL. Power rushes through your body.',
    GoldStart = 'You swallowed the GOLD PILL. Reality has been altered.',
    Ended = 'Reality Choice effect ended.',
    Cooldown = 'Your body is still processing Reality Choice.',
    CraftSuccess = 'You fused reality and created a GOLD PILL.',
    CraftFail = 'The fusion failed. Reality rejected the craft.',
    NotEnough = 'You do not have the required items or cash.'
}
