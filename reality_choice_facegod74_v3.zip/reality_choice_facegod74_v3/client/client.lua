local active = false
local cooldown = false
local currentEffect = nil

local function notify(msg, ntype)
    if GetResourceState('ox_lib') == 'started' then
        lib.notify({title = Config.Branding.ScriptName, description = msg, type = ntype or 'inform'})
    elseif GetResourceState('qb-core') == 'started' then
        TriggerEvent('QBCore:Notify', msg, ntype or 'primary')
    else
        BeginTextCommandThefeedPost('STRING')
        AddTextComponentSubstringPlayerName(msg)
        EndTextCommandThefeedPostTicker(false, true)
    end
end

local function nui(show, pill, duration)
    SendNUIMessage({
        action = show and 'show' or 'hide',
        pill = pill,
        duration = duration or 0,
        title = Config.Branding.ScriptName,
        madeBy = Config.Branding.MadeBy
    })
end

local function resetEffects()
    active = false
    currentEffect = nil
    ClearTimecycleModifier()
    StopGameplayCamShaking(true)
    SetRunSprintMultiplierForPlayer(PlayerId(), 1.0)
    SetSwimMultiplierForPlayer(PlayerId(), 1.0)
    SetNightvision(false)
    SetSeethrough(false)
    RestorePlayerStamina(PlayerId(), 1.0)
    nui(false)
end

local function realityCrash()
    local ped = PlayerPedId()
    notify('Reality Crash hit your body.', 'error')
    SetTimecycleModifier('Drunk')
    ShakeGameplayCam('DRUNK_SHAKE', 0.75)
    SetPedMoveRateOverride(ped, 0.75)
    SetRunSprintMultiplierForPlayer(PlayerId(), 0.8)
    Wait(Config.Durations.RealityCrash * 1000)
    resetEffects()
end

local function applyEffect(pill)
    if active then
        notify('You already have an active Reality Choice effect.', 'error')
        return
    end
    if cooldown then
        notify(Config.Notifications.Cooldown, 'error')
        return
    end

    local settings = Config.Effects[pill]
    if not settings then return end

    active = true
    cooldown = true
    currentEffect = pill

    local duration = Config.Durations[pill] or 120
    local ped = PlayerPedId()

    SetTimecycleModifier(settings.Timecycle)
    SetTimecycleModifierStrength(0.85)
    ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', settings.ScreenShake or 0.1)
    SetRunSprintMultiplierForPlayer(PlayerId(), settings.MovementMultiplier or 1.0)
    SetSwimMultiplierForPlayer(PlayerId(), settings.MovementMultiplier or 1.0)

    if settings.EnableNightVision then SetNightvision(true) end
    if settings.EnableThermal then SetSeethrough(true) end
    if settings.ArmorBonus and settings.ArmorBonus > 0 then
        SetPedArmour(ped, math.min(100, GetPedArmour(ped) + settings.ArmorBonus))
    end

    if pill == 'Blue' then notify(Config.Notifications.BlueStart, 'inform') end
    if pill == 'Red' then notify(Config.Notifications.RedStart, 'error') end
    if pill == 'Gold' then notify(Config.Notifications.GoldStart, 'success') end

    nui(true, pill, duration)

    CreateThread(function()
        local endAt = GetGameTimer() + (duration * 1000)
        while active and currentEffect == pill and GetGameTimer() < endAt do
            if pill == 'Red' or pill == 'Gold' then
                RestorePlayerStamina(PlayerId(), 1.0)
            end
            if pill == 'Blue' then
                -- subtle detective feel: controlled, clearer movement
                SetPedMoveRateOverride(PlayerPedId(), 1.0)
            end
            Wait(1000)
        end

        local shouldCrash = false
        if active and currentEffect == 'Gold' then
            shouldCrash = math.random(1, 100) <= (Config.Effects.Gold.RealityCrashChance or 0)
        end

        resetEffects()
        TriggerServerEvent('reality_choice:server:effectEnded')
        notify(Config.Notifications.Ended, 'inform')

        if shouldCrash then
            realityCrash()
        end
    end)

    CreateThread(function()
        Wait(Config.Cooldown * 1000)
        cooldown = false
    end)
end

RegisterNetEvent('reality_choice:client:usePill', function(pill)
    applyEffect(pill)
end)

RegisterNetEvent('reality_choice:client:notify', function(msg, ntype)
    notify(msg, ntype)
end)

RegisterNetEvent('reality_choice:client:serverAnnouncement', function(msg)
    notify(msg, 'success')
end)

RegisterCommand(Config.Commands.ClearEffectCommand, function()
    resetEffects()
    notify('Reality Choice effects cleared.', 'inform')
end, false)

RegisterNetEvent('onResourceStop', function(resource)
    if resource == GetCurrentResourceName() then
        resetEffects()
    end
end)
