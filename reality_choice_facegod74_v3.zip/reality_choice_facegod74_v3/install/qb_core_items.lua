-- Put these inside qb-core/shared/items.lua

reality_bluepill = { name = 'reality_bluepill', label = 'Blue Pill', weight = 50, type = 'item', image = 'reality_bluepill.png', unique = false, useable = true, shouldClose = true, description = 'Reality Choice: Take the truth.' },
reality_redpill = { name = 'reality_redpill', label = 'Red Pill', weight = 50, type = 'item', image = 'reality_redpill.png', unique = false, useable = true, shouldClose = true, description = 'Reality Choice: Take the power.' },
reality_goldpill = { name = 'reality_goldpill', label = 'Gold Pill', weight = 50, type = 'item', image = 'reality_goldpill.png', unique = false, useable = true, shouldClose = true, description = 'Reality Choice: The 1% ascension pill.' },
