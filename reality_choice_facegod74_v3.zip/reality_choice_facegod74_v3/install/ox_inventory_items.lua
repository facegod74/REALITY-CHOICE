-- Put these inside ox_inventory/data/items.lua

['reality_bluepill'] = {
    label = 'Blue Pill',
    weight = 50,
    stack = true,
    close = true,
    description = 'Reality Choice: Take the truth.',
    client = { image = 'reality_bluepill.png' },
    server = { event = 'reality_choice:server:oxUse', args = 'Blue' }
},

['reality_redpill'] = {
    label = 'Red Pill',
    weight = 50,
    stack = true,
    close = true,
    description = 'Reality Choice: Take the power.',
    client = { image = 'reality_redpill.png' },
    server = { event = 'reality_choice:server:oxUse', args = 'Red' }
},

['reality_goldpill'] = {
    label = 'Gold Pill',
    weight = 50,
    stack = true,
    close = true,
    description = 'Reality Choice: The 1% ascension pill.',
    client = { image = 'reality_goldpill.png' },
    server = { event = 'reality_choice:server:oxUse', args = 'Gold' }
},
