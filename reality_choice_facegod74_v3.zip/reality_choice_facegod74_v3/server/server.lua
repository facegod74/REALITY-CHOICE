local QBCore, ESX = nil, nil

CreateThread(function()
    if Config.Framework == 'qb' and GetResourceState('qb-core') == 'started' then
        QBCore = exports['qb-core']:GetCoreObject()
    elseif Config.Framework == 'esx' and GetResourceState('es_extended') == 'started' then
        ESX = exports['es_extended']:getSharedObject()
    end
end)

local function notify(src, msg, ntype)
    TriggerClientEvent('reality_choice:client:notify', src, msg, ntype or 'inform')
end

-- Server-side protection so used pills are consumed once, and players cannot
-- burn extra pills while an effect is already active or on cooldown.
local activeUntil = {}
local cooldownUntil = {}

local function now()
    return os.time()
end

local function isPlayerLocked(src)
    local t = now()
    if (activeUntil[src] or 0) > t then return true, 'active' end
    if (cooldownUntil[src] or 0) > t then return true, 'cooldown' end
    return false, nil
end

AddEventHandler('playerDropped', function()
    local src = source
    activeUntil[src] = nil
    cooldownUntil[src] = nil
end)

local function hasOx()
    return Config.Inventory == 'ox' and GetResourceState('ox_inventory') == 'started'
end

local function addItem(src, item, count)
    count = count or 1
    if hasOx() then return exports.ox_inventory:AddItem(src, item, count) end
    if QBCore then return QBCore.Functions.GetPlayer(src).Functions.AddItem(item, count) end
    if ESX then return ESX.GetPlayerFromId(src).addInventoryItem(item, count) end
    return true
end

local function removeItem(src, item, count)
    count = count or 1
    if hasOx() then return exports.ox_inventory:RemoveItem(src, item, count) end
    if QBCore then return QBCore.Functions.GetPlayer(src).Functions.RemoveItem(item, count) end
    if ESX then return ESX.GetPlayerFromId(src).removeInventoryItem(item, count) end
    return true
end

local function getItemCount(src, item)
    if hasOx() then return exports.ox_inventory:GetItemCount(src, item) or 0 end
    if QBCore then
        local Player = QBCore.Functions.GetPlayer(src)
        local it = Player and Player.Functions.GetItemByName(item)
        return it and it.amount or 0
    end
    if ESX then
        local xPlayer = ESX.GetPlayerFromId(src)
        local it = xPlayer and xPlayer.getInventoryItem(item)
        return it and it.count or 0
    end
    return 999
end

local function getCash(src)
    if QBCore then
        local Player = QBCore.Functions.GetPlayer(src)
        return Player and Player.PlayerData.money.cash or 0
    end
    if ESX then
        local xPlayer = ESX.GetPlayerFromId(src)
        return xPlayer and xPlayer.getMoney() or 0
    end
    return 999999999
end

local function removeCash(src, amount)
    amount = amount or 0
    if amount <= 0 then return true end
    if QBCore then
        local Player = QBCore.Functions.GetPlayer(src)
        return Player and Player.Functions.RemoveMoney('cash', amount, 'reality-choice-gold-craft')
    end
    if ESX then
        local xPlayer = ESX.GetPlayerFromId(src)
        if xPlayer and xPlayer.getMoney() >= amount then xPlayer.removeMoney(amount) return true end
        return false
    end
    return true
end

local function registerUsables()
    if QBCore then
        QBCore.Functions.CreateUseableItem(Config.Items.Blue, function(source) TriggerEvent('reality_choice:server:usePill', source, 'Blue') end)
        QBCore.Functions.CreateUseableItem(Config.Items.Red, function(source) TriggerEvent('reality_choice:server:usePill', source, 'Red') end)
        QBCore.Functions.CreateUseableItem(Config.Items.Gold, function(source) TriggerEvent('reality_choice:server:usePill', source, 'Gold') end)
    end
    if ESX then
        ESX.RegisterUsableItem(Config.Items.Blue, function(source) TriggerEvent('reality_choice:server:usePill', source, 'Blue') end)
        ESX.RegisterUsableItem(Config.Items.Red, function(source) TriggerEvent('reality_choice:server:usePill', source, 'Red') end)
        ESX.RegisterUsableItem(Config.Items.Gold, function(source) TriggerEvent('reality_choice:server:usePill', source, 'Gold') end)
    end
end

CreateThread(function()
    Wait(1500)
    registerUsables()
end)

RegisterNetEvent('reality_choice:server:usePill', function(srcOrPill, maybePill)
    local src = source
    local pill = srcOrPill
    if type(srcOrPill) == 'number' then src = srcOrPill pill = maybePill end

    local item = Config.Items[pill]
    if not item then return end

    local locked, reason = isPlayerLocked(src)
    if locked then
        if reason == 'active' then
            notify(src, 'You already have an active Reality Choice effect.', 'error')
        else
            notify(src, Config.Notifications.Cooldown, 'error')
        end
        return
    end

    if Config.Inventory ~= 'none' and getItemCount(src, item) < 1 then
        notify(src, 'You do not have this pill.', 'error')
        return
    end

    -- IMPORTANT: The pill is removed from inventory right here before the effect starts.
    -- This makes Blue, Red, and Gold true one-time consumables.
    if Config.Inventory ~= 'none' then
        local removed = removeItem(src, item, 1)
        if removed == false then
            notify(src, 'Could not remove pill from inventory.', 'error')
            return
        end
    end

    local duration = (Config.Durations[pill] or 120)
    activeUntil[src] = now() + duration + 2
    cooldownUntil[src] = now() + duration + (Config.Cooldown or 20)

    TriggerClientEvent('reality_choice:client:usePill', src, pill)
end)

-- ox_inventory item server event. Supports direct args and ox item payload variants.
RegisterNetEvent('reality_choice:server:oxUse', function(pill)
    if type(pill) == 'table' then
        pill = pill.args or pill.pill or pill.name
        if pill == Config.Items.Blue then pill = 'Blue' end
        if pill == Config.Items.Red then pill = 'Red' end
        if pill == Config.Items.Gold then pill = 'Gold' end
    end
    TriggerEvent('reality_choice:server:usePill', source, pill)
end)

RegisterNetEvent('reality_choice:server:effectEnded', function()
    local src = source
    activeUntil[src] = nil
end)

RegisterCommand(Config.GoldCrafting.Command, function(source)
    if source <= 0 then return end
    if not Config.GoldCrafting.Enabled then return end

    local blue = getItemCount(source, Config.Items.Blue)
    local red = getItemCount(source, Config.Items.Red)
    local cash = getCash(source)

    if blue < Config.GoldCrafting.BlueRequired or red < Config.GoldCrafting.RedRequired or cash < Config.GoldCrafting.CashCost then
        notify(source, Config.Notifications.NotEnough, 'error')
        return
    end

    removeCash(source, Config.GoldCrafting.CashCost)
    removeItem(source, Config.Items.Blue, Config.GoldCrafting.BlueRequired)
    removeItem(source, Config.Items.Red, Config.GoldCrafting.RedRequired)

    local roll = math.random(1, 100)
    if roll <= Config.GoldCrafting.SuccessChance then
        addItem(source, Config.Items.Gold, 1)
        notify(source, Config.Notifications.CraftSuccess, 'success')
        if Config.GoldCrafting.AnnounceSuccess then
            TriggerClientEvent('reality_choice:client:serverAnnouncement', -1, '⚡ REALITY HAS BEEN ALTERED ⚡ A Gold Pill has been created somewhere in Los Santos.')
        end
    else
        if not Config.GoldCrafting.ConsumeItemsOnFail then
            addItem(source, Config.Items.Blue, Config.GoldCrafting.BlueRequired)
            addItem(source, Config.Items.Red, Config.GoldCrafting.RedRequired)
        end
        if Config.GoldCrafting.RefundCashOnFail then
            if QBCore then QBCore.Functions.GetPlayer(source).Functions.AddMoney('cash', Config.GoldCrafting.CashCost, 'reality-choice-refund') end
            if ESX then ESX.GetPlayerFromId(source).addMoney(Config.GoldCrafting.CashCost) end
        end
        notify(source, Config.Notifications.CraftFail, 'error')
    end
end, false)

RegisterCommand(Config.Commands.GiveTestCommand, function(source)
    if source <= 0 or not Config.Commands.GiveTestPills then return end
    addItem(source, Config.Items.Blue, 5)
    addItem(source, Config.Items.Red, 5)
    addItem(source, Config.Items.Gold, 1)
    notify(source, 'Test pills added. Disable Config.Commands.GiveTestPills before public launch.', 'success')
end, false)
