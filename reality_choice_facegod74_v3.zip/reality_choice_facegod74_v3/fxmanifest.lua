fx_version 'cerulean'
game 'gta5'

name 'Reality Choice'
author 'facegod74'
description 'Reality Choice - Blue Pill / Red Pill / 1% Gold Pill crafting experience for FiveM'
version '2.0.0'

lua54 'yes'

shared_scripts {
    'shared/config.lua'
}

client_scripts {
    'client/client.lua'
}

server_scripts {
    'server/server.lua'
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js',
    'img/reality_bluepill.png',
    'img/reality_redpill.png',
    'img/reality_goldpill.png'
}
